This test does some EVM execution, and can be used to test the tracers and trace-outputs.
